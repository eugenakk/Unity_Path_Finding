﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour
{

    public Transform target;
    public float dist = 1.0f;
    public float height = 5.0f;
    public float smoothRotate = 2.0f;

    private Transform tr;
    

    void Start()
    {
        tr = GetComponent<Transform>();
    }

    void LateUpdate()
    {

        float currYAngle = Mathf.LerpAngle(tr.eulerAngles.y, target.eulerAngles.y,
            smoothRotate * Time.deltaTime);

        Quaternion rot = Quaternion.Euler(0, currYAngle, 0);

        tr.position = target.position - (rot * Vector3.forward * dist) + (Vector3.up * height);

        tr.LookAt(target);
    }
}


//카메라 회전하는 코드 추가**** 