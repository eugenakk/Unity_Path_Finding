﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//navigation관련 기능을 사용할 때 필요!
using UnityEngine.AI;

public class PlayerController : MonoBehaviour
{

    public Transform target;
    NavMeshAgent agent;

    void Start()
    {
        //해당 개체의 NaMESHAGENT를 참조
        agent = GetComponent<NavMeshAgent>();


    }
    // Update is called once per frame
    void Update()
    {
        agent.SetDestination(target.position);

    }


}
